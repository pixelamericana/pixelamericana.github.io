Pixel Americana stickers for WhatsApp

WhatsApp only adds stickers through a sticker app. Free options: "Sticker Maker" (iPhone and Android) or
"Personal Stickers for WhatsApp" (Android). Create a pack, import the .webp files, then tap Add to WhatsApp.
Use the static folder for one pack and the animated folder for another: WhatsApp doesn't allow mixing them.
Each folder has a tray.png for the pack icon. On iPhone you can also long-press any sticker image and add it directly.

Free for personal use. pixelamericana.github.io
