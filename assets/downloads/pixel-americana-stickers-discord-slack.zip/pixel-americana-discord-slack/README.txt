Pixel Americana emoji for Discord and Slack

Discord: Server Settings > Emoji > Upload Emoji. Pick the .gif for the moving ones (animated emoji need Nitro to USE outside
the server they're on, but anyone can upload them to a server). Name them anything, e.g. :pa_flag:.
Slack: click your workspace name > Tools & settings > Customize workspace > Emoji > Add custom emoji.

All files are 128x128. GIFs are the animated versions; PNGs are stills.

Free for personal use. pixelamericana.github.io
