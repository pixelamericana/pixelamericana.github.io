window.PA_CONFIG = {"assets": "", "home": "https://pixelamericana.github.io/"};
