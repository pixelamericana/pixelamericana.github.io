Pixel Americana stickers for Signal

Signal Desktop > File > Create/upload sticker pack. Drag in the .png files (the animated ones are APNGs and move),
choose an emoji for each, then Upload. Signal gives you a link you can share.

Free for personal use. pixelamericana.github.io
