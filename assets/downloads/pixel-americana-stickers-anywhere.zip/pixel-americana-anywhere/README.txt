Pixel Americana stickers: plain files

512x512 PNGs with a white die-cut border on transparency, plus 256x256 GIFs of the animated ones.
Use them in texts, iMessage (drag or paste), Notion, Google Docs, slides, Instagram stories, anywhere.

Free for personal use. pixelamericana.github.io
