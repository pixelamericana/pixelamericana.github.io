Pixel Americana stickers for Telegram (free)

1. In Telegram, open a chat with @Stickers (the official sticker bot).
2. Static pack: send /newpack, give it a name, then send each .png as a FILE (not a photo) with one emoji.
3. Animated pack: send /newvideo and send each .webm the same way.
4. Send /publish, pick an icon and a short name (e.g. PixelAmericana).
Static and video stickers go in separate packs.

Free for personal use. pixelamericana.github.io
