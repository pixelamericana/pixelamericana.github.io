window.PA_CONFIG = {"assets": "", "music": "https://pixelamericana.github.io/music/", "home": "https://pixelamericana.github.io/"};
